package main.java.ua.nure.kn.kornienko.usermanagement.db;

import java.sql.SQLException;

public class DatabaseException extends Exception {

//    public DatabaseException(ClassNotFoundException e) {
//
//    }
//
//    public DatabaseException(SQLException e) {
//
//    }
public DatabaseException() {
    // TODO Auto-generated constructor stub
}

    public DatabaseException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public DatabaseException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public DatabaseException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

    public DatabaseException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
        super(arg0, arg1, arg2, arg3);
        // TODO Auto-generated constructor stub
    }

}
